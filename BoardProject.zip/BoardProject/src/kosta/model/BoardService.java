package kosta.model;

import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

public class BoardService {
	//서비스에서 dao 호출 
	//싱글톤 형식 : private
	private static BoardService service = new BoardService();
	private static BoardDao dao;
	private static final int PAGE_SIZE = 2;
	
	public static BoardService getInstance(){
		dao = BoardDao.getInstance();		
		return service;
	}

	//데이터 삽입 - inesertOk
	public int insertBoardService(Board board)throws Exception{	
		//답변글일때
		if(board.getB_id() != 0){
			HashMap<String, Integer> map =
					new HashMap<String, Integer>();
			
			//map.put("변수명",값) :변수명은 xml #{ 변수명}
			map.put("b_step", board.getB_step());
			map.put("b_ref", board.getB_ref());	
			
			dao.updateStep(map);
						
			//뒤로 한칸씩밀려나도록
			board.setB_id(dao.selectB_id()+1);
			board.setB_step(board.getB_step()+1);
			board.setB_level(board.getB_level()+1); //들여쓰기
			
		}else{ //원본글
			board.setB_id(dao.selectB_id()+1); //새로운 b_id , 처음에 b_id를 null을 지님
			board.setB_ref(dao.selectB_id()+1); //원본글 b_ref : 그룹번호
		}
		
		return dao.insertBoard(board);
	}
	
	//리스트- list.jsp 
	public ListModel listBoardService(HttpServletRequest request, int requestPage){
		Search search = new Search();
		
		//검색시
		if(request.getParameterValues("area") != null){
			search.setArea(request.getParameterValues("area"));
			search.setSearchKey("%"+request.getParameter("searchKey")+"%");
		}
		
		/* 페이징 처리 */
		//페이지당 글 갯수, 총 글 갯수, 현재페이지,시작페이지,마지막페이지 => 페이징 UI
		//startRow, endRow => 데이터 출력
		int totalCount = dao.countBoard(); //전체 글내용
		int totalPageCount = totalCount/PAGE_SIZE; //페이지번호
		
		if(totalCount%PAGE_SIZE >0){ //페이지 넘겨서 데이터 이동
			totalPageCount++;
		}
		//시작페이지 = 현재페이지 - (현재페이지 -1)%5(보여주고싶은 페이지수)
		int startPage = requestPage - (requestPage-1)%5;
		int endPage = startPage +4;
		if(endPage > totalPageCount){
			endPage = totalPageCount;
		}
		
		int startRow = (requestPage-1) * PAGE_SIZE;
		List<Board> list = dao.listBoard(search, startRow);
		
		return new ListModel(list, requestPage, totalPageCount, startPage, endPage);
	}
	
	//selectboard 호출 , 파라미터가 b_id와 ture : 조회랑 조회수 업데이트 
	//detail에서는 true , insertform에서는 false를 반환
	//디테일 - detail, selectboard 호출
	public Board selectBoardService(int b_id, boolean check){			
		if(check){		
			dao.hitCount(b_id);
		}
		return dao.selectBoard(b_id);
	}
	
	//수정 - pw일치 
	public int updateBoardService(Board board){
		return dao.updateBoard(board);
	}
	
}
